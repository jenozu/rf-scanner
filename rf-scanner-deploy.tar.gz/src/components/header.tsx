export default function Header() {
  return (
    <header className="bg-primary text-white py-3 shadow-md text-center text-lg font-semibold">
      📦 RF Inventory Counter
    </header>
  );
}
